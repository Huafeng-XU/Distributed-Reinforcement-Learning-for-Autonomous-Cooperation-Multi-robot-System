import rospy
from std_srvs.srv import Empty
from geometry_msgs.msg import Twist
from std_msgs.msg import Float64, UInt8, Bool
from sensor_msgs.msg import LaserScan, CompressedImage
from nav_msgs.msg import Odometry
from math import radians
import numpy as np
import copy
import time
import cv2
from skimage.transform import rotate, AffineTransform, warp
from PIL import Image, ImageEnhance
import random
import math

INPUT_DIM=(120, 200, 1)
transform_type_dict = dict(
    brightness=ImageEnhance.Brightness, contrast=ImageEnhance.Contrast,
    sharpness=ImageEnhance.Sharpness, color=ImageEnhance.Color
)

class ColorJitter(object):
    def __init__(self, transform_dict):
        self.transforms = [(transform_type_dict[k], transform_dict[k]) for k in transform_dict]

    def __call__(self, img):
        out = img
        rand_num = np.random.uniform(0, 1, len(self.transforms))
        for i, (transformer, alpha) in enumerate(self.transforms):
            r = alpha * (rand_num[i] * 2.0 - 1.0) + 1  # r in [1-alpha, 1+alpha)
            out = transformer(out).enhance(r)
        return out
class Env(object):
    def __init__(self):
        rospy.init_node('gazebo_env_node')
        self.sub_lane = rospy.Subscriber('/robot5/detect/lane', Float64, self.cbFollowLane, queue_size=1)
        #self.sub_speed = rospy.Subscriber('/robot5/cmd_vel', Twist, self.speedCallBack, queue_size=1)
        self.pub_cmd_vel = rospy.Publisher('/robot5/cmd_vel', Twist, queue_size=1)
        self.sub_odom = rospy.Subscriber('/robot5/odom', Odometry, self.getOdometry)
        self.sub_scan = rospy.Subscriber('/robot5/camera/image_projected/compressed', CompressedImage, self.imgCallback, queue_size=1)
        self.pub_construct_lane = rospy.Publisher('/robot5/detect/construct_lane', Bool, queue_size=1)
        self.init_speed=[0.06,0.0]
        self.last_pos=[-0.574910,0.627879]
        self.linear_step=0.01
        self.angular_step=0.01
        self.target_speed=[0.06,0.0]
        self.cur_center=500
        self.cv_image=np.zeros([1,120,200])
        self.counter=1
        self.rw_scale=20

    def reset(self):
        print('enter reset')
        self.target_speed = [0.06, 0.0]
        self.cur_center = 500
        self.last_pos = [-0.574910, 0.627879]
        reset_simulation = rospy.ServiceProxy('/gazebo/reset_world', Empty)
        reset_simulation()
        self.pub_construct_lane.publish(Bool(data=False))
        time.sleep(0.1)
        self.pub_construct_lane.publish(Bool(data=False))
        time.sleep(0.5)
        obs=self.get_obs()
        return obs, self.target_speed

    def get_obs(self):
        obs=self.cv_image
        return obs

    def step(self, action):
        print('enter step: ', action)
        linear_step=action[0]*0.01
        print('linear step: ', linear_step)
        angular_step=action[1]*0.01
        self.target_speed[0]=np.clip(self.target_speed[0]+linear_step, 0, 0.15)
        self.target_speed[1]=np.clip(self.target_speed[1]+angular_step, -0.2, 0.2)
        twist=Twist()
        twist.linear.x=self.target_speed[0]
        twist.linear.y =0
        twist.linear.z=0
        twist.angular.x=0
        twist.angular.y=0
        twist.angular.z=self.target_speed[1]
        print('linear_speed: ', self.target_speed[0], ' angular_speed: ', self.target_speed[1])
        self.pub_cmd_vel.publish(twist)
        time.sleep(0.1)
        print('current center: ', self.cur_center)
        if 300<self.cur_center<650:
            if self.target_speed[0]==0:
                print('enter linear_speed==0')
                done=True
                reward=0
            else:
                done = False
                reward = self.rw_scale * math.sqrt(
                    (self.last_pos[0] - self.pos[0]) ** 2 + (self.last_pos[1] - self.pos[1]) ** 2)
                self.last_pos = self.pos
        else:
            reward=-20
            done=True
        next_obs=self.get_obs()
        return next_obs,self.target_speed, reward,done


    def imgCallback(self, image_msg):
        if self.counter % 3 != 0:
            self.counter += 1
            return
        else:
            self.counter = 1
        np_arr = np.fromstring(image_msg.data, np.uint8)
        cv_image = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        im = cv2.resize(cv_image, (200, 120), interpolation=cv2.INTER_AREA)
        _transform_dict = {'brightness': 0.5, 'contrast': 0.3, 'sharpness': 0.8386, 'color': 0.1592}
        _color_jitter = ColorJitter(_transform_dict)
        im = Image.fromarray(im)
        im = _color_jitter(im)
        # 做完color jitter之后，再将Image对象转回numpy array
        im = np.array(im)  # 转换完之后，这里的img是unit8类型的
        # 2. gaussian filter
        im = cv2.GaussianBlur(im, (5, 5), 0)
        # 3. color to gray
        im = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
        im = im.reshape(INPUT_DIM)
        # transform the image x
        if random.random() > 0.8:
            angle = random.randint(-15, 15)
            transform = AffineTransform(translation=(angle, 0))  # (-200,0) are x and y coordinate
            im = warp(im, transform, mode="constant") * 255.
        self.cv_image=im.reshape(1,120,200)
        cv2.imwrite('test.png', self.cv_image)

    def cbFollowLane(self, desired_center):
        center = desired_center.data
        self.cur_center=center

    def getOdometry(self, odom):
        self.pos = [odom.pose.pose.position.x,odom.pose.pose.position.y]